package com.example.myo_keyboard;

public interface IReportEmg {
    void OnReportEmg(int[][] channels);
}
